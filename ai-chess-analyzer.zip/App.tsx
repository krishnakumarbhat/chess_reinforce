
import React, { useState, useCallback } from 'react';
import { fetchChesscomGames, fetchLichessGames } from './services/chessApiService';
import { analyzeGamesPgn } from './services/geminiService';
import { LoadingSpinner } from './components/LoadingSpinner';
import { ChessKnightIcon, DownloadIcon, SparklesIcon, UserIcon, AtIcon } from './components/IconComponents';

const App: React.FC = () => {
  const [chesscomUsername, setChesscomUsername] = useState('');
  const [lichessUsername, setLichessUsername] = useState('');
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleAnalysis = useCallback(async () => {
    if (!chesscomUsername && !lichessUsername) {
      setError('Please enter at least one username.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setAnalysis(null);

    try {
      let combinedPgn = '';
      
      if (chesscomUsername) {
        setLoadingMessage('Fetching recent games from Chess.com...');
        const chesscomPgn = await fetchChesscomGames(chesscomUsername);
        if (chesscomPgn) {
          combinedPgn += chesscomPgn + '\n\n';
        }
      }
      
      if (lichessUsername) {
        setLoadingMessage('Fetching recent games from Lichess.org...');
        const lichessPgn = await fetchLichessGames(lichessUsername);
        if (lichessPgn) {
          combinedPgn += lichessPgn;
        }
      }

      if (!combinedPgn.trim()) {
        throw new Error('Could not fetch any games. Please check the usernames and make sure you have recent games played.');
      }

      setLoadingMessage('AI is analyzing your games...');
      const analysisResult = await analyzeGamesPgn(combinedPgn);
      setAnalysis(analysisResult);

    } catch (err: any) {
      setError(err.message || 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  }, [chesscomUsername, lichessUsername]);

  const handleDownload = () => {
    if (!analysis) return;
    const blob = new Blob([analysis], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `chess_analysis_${chesscomUsername || lichessUsername}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex flex-col items-center p-4 sm:p-6">
      <div className="w-full max-w-4xl mx-auto">
        <header className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-2">
            <ChessKnightIcon className="h-10 w-10 text-cyan-400" />
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight text-white">
              AI Chess Analyzer
            </h1>
          </div>
          <p className="text-lg text-gray-400">
            Get your recent games analyzed by Gemini to find your strengths and weaknesses.
          </p>
        </header>

        <main className="bg-gray-800/50 rounded-2xl shadow-lg p-6 sm:p-8 border border-gray-700 backdrop-blur-sm">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="relative">
              <label htmlFor="chesscom" className="block text-sm font-medium text-gray-300 mb-2">Chess.com Username</label>
              <div className="relative">
                <AtIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-500" />
                <input
                  id="chesscom"
                  type="text"
                  value={chesscomUsername}
                  onChange={(e) => setChesscomUsername(e.target.value)}
                  placeholder="e.g., Hikaru"
                  className="w-full pl-10 pr-4 py-2 bg-gray-900 border border-gray-600 rounded-md focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-colors"
                />
              </div>
            </div>
            <div className="relative">
              <label htmlFor="lichess" className="block text-sm font-medium text-gray-300 mb-2">Lichess.org Username</label>
               <div className="relative">
                <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-500" />
                <input
                  id="lichess"
                  type="text"
                  value={lichessUsername}
                  onChange={(e) => setLichessUsername(e.target.value)}
                  placeholder="e.g., MagnusCarlsen"
                  className="w-full pl-10 pr-4 py-2 bg-gray-900 border border-gray-600 rounded-md focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-colors"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-center mt-6">
            <button
              onClick={handleAnalysis}
              disabled={isLoading}
              className="flex items-center justify-center gap-2 px-8 py-3 bg-cyan-600 text-white font-semibold rounded-lg shadow-md hover:bg-cyan-500 disabled:bg-gray-600 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105"
            >
              <SparklesIcon className="h-5 w-5" />
              Analyze My Games
            </button>
          </div>

          <div className="mt-8">
            {isLoading && (
              <div className="text-center p-8 bg-gray-900/50 rounded-lg">
                <LoadingSpinner />
                <p className="mt-4 text-lg font-medium text-cyan-400">{loadingMessage}</p>
                <p className="text-gray-400">This may take a moment...</p>
              </div>
            )}
            {error && (
              <div className="text-center p-4 bg-red-900/50 border border-red-700 text-red-300 rounded-lg">
                <p className="font-bold">Error</p>
                <p>{error}</p>
              </div>
            )}
            {analysis && (
              <div className="bg-gray-900/50 p-6 rounded-lg border border-gray-700">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-2xl font-bold text-white">Analysis Results</h2>
                  <button 
                    onClick={handleDownload}
                    className="flex items-center gap-2 px-4 py-2 bg-gray-700 text-gray-200 font-medium rounded-lg hover:bg-gray-600 transition-colors"
                  >
                    <DownloadIcon className="h-5 w-5" />
                    Download
                  </button>
                </div>
                <div 
                  className="prose prose-invert max-w-none text-gray-300 whitespace-pre-wrap" 
                  style={{
                    // @ts-ignore
                    '--tw-prose-body': '#d1d5db',
                    '--tw-prose-headings': '#ffffff',
                    '--tw-prose-bold': '#ffffff',
                    '--tw-prose-bullets': '#67e8f9',
                  }}
                  dangerouslySetInnerHTML={{ __html: analysis.replace(/\n/g, '<br />').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\* (.*?)(<br \/>|$)/g, '<ul class="list-disc list-inside"><li>$1</li></ul>') }}
                >
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;
