
const fetchChesscomGames = async (username: string): Promise<string> => {
  try {
    const now = new Date();
    // Get last month's data, as current month might be incomplete.
    now.setMonth(now.getMonth() - 1);
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    
    const url = `https://api.chess.com/pub/player/${username}/games/${year}/${month}/pgn`;
    
    const response = await fetch(url);
    if (!response.ok) {
      if(response.status === 404) {
        throw new Error(`Could not find Chess.com user '${username}' or they have no games in the last month.`);
      }
      throw new Error(`Failed to fetch games from Chess.com. Status: ${response.status}`);
    }
    return await response.text();
  } catch (error: any) {
    console.error("Error fetching from Chess.com:", error);
    throw new Error(error.message || 'An error occurred while fetching Chess.com games.');
  }
};

const fetchLichessGames = async (username: string): Promise<string> => {
  try {
    // Fetch last 50 rated rapid, classical, and blitz games
    const url = `https://lichess.org/api/games/user/${username}?max=50&pgns=true&perfType=rapid,classical,blitz&rated=true`;
    
    const response = await fetch(url, {
      headers: {
        'Accept': 'application/x-chess-pgn'
      }
    });

    if (!response.ok) {
       if(response.status === 404) {
        throw new Error(`Could not find Lichess.org user '${username}'.`);
      }
      throw new Error(`Failed to fetch games from Lichess.org. Status: ${response.status}`);
    }
    
    const text = await response.text();
    if (!text) {
        throw new Error(`No recent rated games found for Lichess.org user '${username}'.`);
    }
    return text;
  } catch (error: any) {
    console.error("Error fetching from Lichess.org:", error);
    throw new Error(error.message || 'An error occurred while fetching Lichess.org games.');
  }
};

export { fetchChesscomGames, fetchLichessGames };
