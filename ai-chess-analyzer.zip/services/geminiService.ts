
import { GoogleGenAI } from "@google/genai";

const analyzeGamesPgn = async (pgnString: string): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set.");
  }
  
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const prompt = `
You are a world-class chess coach with deep strategic and tactical knowledge. Analyze the following chess games provided in PGN format. The user wants to understand their strengths and weaknesses.

Please provide a detailed, structured analysis covering these points:

**1. Overall Summary:**
   - A brief overview of the player's style (e.g., aggressive, positional, tactical).
   - Key takeaways and most important areas to focus on.

**2. Strengths:**
   - Identify specific positive patterns. Is the player good at tactics, positional play, specific openings, or endgames?
   - Provide 2-3 concrete examples from the games. Cite the game if possible.

**3. Weaknesses:**
   - Identify the most critical areas for improvement. Are there recurring blunders, poor time management (inferred from move quality), specific opening issues, or endgame inaccuracies?
   - Provide 2-3 concrete examples of mistakes or missed opportunities.

**4. Actionable Advice:**
   - Suggest concrete steps the player can take to improve their weaknesses and build on their strengths.
   - Recommend specific openings to study, types of tactical puzzles to solve, or strategic concepts to learn.

Format your response in clear, easy-to-read Markdown. Use headings, bullet points, and bold text to structure your analysis. Be encouraging and constructive.

Here are the games:
\n\n
${pgnString}
  `;

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: prompt
    });
    return response.text;
  } catch (error: any) {
    console.error("Error calling Gemini API:", error);
    throw new Error("The AI model failed to generate an analysis. Please try again.");
  }
};

export { analyzeGamesPgn };
