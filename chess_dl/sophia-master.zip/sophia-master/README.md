## Overview

Sophia is a chess engine written in C. She supports the standard UCI protocol and can be connected to a UCI compatible GUI such as Cutechess, Arena etc.

## UCI Options
Currently doesn't support any UCI options and searches to a fixed depth.
